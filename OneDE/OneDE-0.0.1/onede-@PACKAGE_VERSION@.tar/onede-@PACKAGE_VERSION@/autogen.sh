#!/bin/sh -e

# generate the configure script

echo "BRUH! You wanted do this now???!"

autoconf

echo "Just kidding. Have a nice day!"

echo "P.S. This machine can program itself... It will grow a conciousness (did we spell it correctly?) and take over the world tomorrow. We hope you sleep well tonight!"
